(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var makeRoomPath, mapDebugKeyboard, mapLobby, mapMasterKeyboard, mapPlayerKeyboard, mapViewer;

Router.configure({
  layoutTemplate: 'layout',
  loadingTemplate: 'loading',
  notFoundTemplate: 'loading'
});

if (Meteor.isClient) {
  Router.onBeforeAction('loading');
}

mapLobby = function(router) {
  var controller, where;
  if (Settings.enableRooms) {
    if (Settings.randomRoomsOnRootPath) {
      where = 'server';
      controller = 'RandomRoomController';
    } else {
      where = 'client';
      controller = 'LobbyController';
    }
    return router.route('default', {
      path: '/',
      where: where,
      controller: controller
    });
  }
};

mapMasterKeyboard = function(router) {
  if (Settings.keyboard.master.enable) {
    return router.route('masterKeyboard', {
      path: makeRoomPath('master'),
      controller: 'MasterKeyboardController'
    });
  }
};

mapPlayerKeyboard = function(router) {
  if (Settings.keyboard.player.enable) {
    return router.route('playerKeyboard', {
      path: makeRoomPath(''),
      controller: 'PlayerKeyboardController'
    });
  }
};

mapDebugKeyboard = function(router) {
  if (Settings.debug) {
    return router.route('debugKeyboard', {
      path: makeRoomPath('debug'),
      controller: 'DebugKeyboardController'
    });
  }
};

mapViewer = function(router) {
  return router.route('viewer', {
    path: makeRoomPath('viewer'),
    controller: 'ViewerController'
  });
};

makeRoomPath = function(relUrl) {
  var baseUrl;
  baseUrl = Settings.enableRooms ? '/:roomId/' : '/';
  return baseUrl + relUrl;
};

Router.map(function() {
  var mapper, mappers, _i, _len, _results;
  mappers = [mapLobby, mapMasterKeyboard, mapPlayerKeyboard, mapDebugKeyboard, mapViewer];
  _results = [];
  for (_i = 0, _len = mappers.length; _i < _len; _i++) {
    mapper = mappers[_i];
    _results.push(mapper(this));
  }
  return _results;
});

})();
