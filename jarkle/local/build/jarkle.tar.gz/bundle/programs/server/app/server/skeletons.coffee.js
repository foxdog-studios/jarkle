(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({
  skeletons: function(roomId, skeletons) {
    check(roomId, String);
    check(skeletons, [Object]);
    return Stream.emit("" + roomId + ":skeletons", skeletons);
  }
});

})();
