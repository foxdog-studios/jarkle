(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('room', function(roomId) {
  check(roomId, String);
  return Rooms.find({
    roomId: roomId
  });
});

Meteor.publish('rooms', function() {
  return Rooms.find();
});

Meteor.publish('player', function() {
  return Players.find({
    playerId: this.connection.id
  });
});

Meteor.publish('players', function() {
  return Players.find();
});

Meteor.publish('playerCount', function(roomId) {
  var count, cursor, handle, initializing;
  check(roomId, String);
  count = 0;
  initializing = true;
  cursor = Players.find({
    roomId: roomId,
    isMaster: false
  });
  handle = cursor.observeChanges({
    added: (function(_this) {
      return function(id) {
        count++;
        if (!initializing) {
          return _this.changed('counts', roomId, {
            count: count
          });
        }
      };
    })(this),
    removed: (function(_this) {
      return function(id) {
        count--;
        return _this.changed('counts', roomId, {
          count: count
        });
      };
    })(this)
  });
  initializing = false;
  this.added('counts', roomId, {
    count: count
  });
  this.ready();
  return this.onStop(function() {
    return handle.stop();
  });
});

})();
