(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({
  drumHit: function(roomId, drumName) {
    check(roomId, String);
    check(drumName, String);
    return Stream.emit("" + roomId + ":drumHit", drumName);
  }
});

})();
