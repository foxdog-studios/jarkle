(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var disableAllPlayers, enableAllPlayers, enableSinglePlayer, hideMessage, joinRoom, leaveRooms, queue, showMessage;

Meteor.methods({
  joinRoom: function(roomId, isMaster) {
    check(roomId, String);
    check(isMaster, Boolean);
    RoomControls.joinRoom(roomId, this.connection.id, isMaster);
    return void 0;
  },
  leaveRooms: function() {
    RoomControls.leaveRooms(this.connection.id);
    return void 0;
  },
  showMessage: function(roomId) {
    check(roomId, String);
    RoomControls.showMessage(roomId);
    return void 0;
  },
  hideMessage: function(roomId) {
    check(roomId, String);
    RoomControls.hideMessage(roomId);
    return void 0;
  },
  enableSinglePlayer: function(roomId) {
    check(roomId, String);
    RoomControls.enableSinglePlayer(roomId);
    return void 0;
  },
  enableAllPlayers: function(roomId) {
    check(roomId, String);
    RoomControls.enableAllPlayers(roomId);
    return void 0;
  },
  disableAllPlayers: function(roomId) {
    check(roomId, String);
    RoomControls.disableAllPlayers(roomId);
    return void 0;
  }
});

queue = new PowerQueue({
  isPaused: true
});

Meteor.startup(function() {
  queue.add(function(done) {
    Players.remove({});
    Rooms.remove({});
    return done();
  });
  return queue.run();
});

this.RoomControls = (function() {
  var add;

  function RoomControls() {}

  add = function(func) {
    return queue.add(function(done) {
      func();
      return done();
    });
  };

  RoomControls.joinRoom = function(roomId, playerId, isMaster) {
    return add(function() {
      return joinRoom(roomId, playerId, isMaster);
    });
  };

  RoomControls.leaveRooms = function(playerId) {
    return add(function() {
      return leaveRooms(playerId);
    });
  };

  RoomControls.showMessage = function(roomId) {
    return add(function() {
      return showMessage(roomId);
    });
  };

  RoomControls.hideMessage = function(roomId) {
    return add(function() {
      return hideMessage(roomId);
    });
  };

  RoomControls.enableSinglePlayer = function(roomId) {
    return add(function() {
      return enableSinglePlayer(roomId);
    });
  };

  RoomControls.enableAllPlayers = function(roomId) {
    return add(function() {
      return enableAllPlayers(roomId);
    });
  };

  RoomControls.disableAllPlayers = function(roomId) {
    return add(function() {
      return disableAllPlayers(roomId);
    });
  };

  return RoomControls;

})();

joinRoom = function(roomId, playerId, isMaster) {
  var allEnabled, isEnabled, room, _ref;
  room = Rooms.findOne({
    roomId: roomId
  }, {
    fields: {
      allEnabled: true
    }
  });
  allEnabled = (_ref = room != null ? room.allEnabled : void 0) != null ? _ref : false;
  isEnabled = isMaster || ServerSettings.players.enableOnJoin ? true : allEnabled;
  Players.upsert({
    playerId: playerId
  }, {
    $set: {
      allEnabled: allEnabled,
      isEnabled: isEnabled,
      isMaster: isMaster,
      name: generateName(),
      roomId: roomId
    },
    $unset: {
      singledAt: ''
    }
  });
  return Rooms.upsert({
    roomId: roomId
  }, {
    $set: {
      roomId: roomId
    }
  });
};

leaveRooms = function(playerId) {
  var player;
  player = Players.findOne({
    playerId: playerId
  });
  if (player == null) {
    return;
  }
  Rooms.find({
    enabledPlayerId: playerId
  }).forEach(function(room) {
    return enableSinglePlayer(room.roomId);
  });
  Players.remove({
    playerId: playerId
  });
  if (Players.find({
    roomId: player.roomId
  }).count() === 0) {
    return Rooms.remove({
      roomId: player.roomId
    });
  }
};

showMessage = function(roomId) {
  return Rooms.upsert({
    roomId: roomId
  }, {
    $set: {
      message: ServerSettings.viewer.message
    }
  });
};

hideMessage = function(roomId) {
  return Rooms.update({
    roomId: roomId
  }, {
    $unset: {
      message: ''
    }
  });
};

enableSinglePlayer = function(roomId) {
  var player;
  player = Players.findOne({
    isMaster: false,
    roomId: roomId
  }, {
    sort: [['singledAt', 'asc']]
  });
  if (player != null) {
    Players.update({
      isEnabled: true,
      roomId: roomId
    }, {
      $set: {
        isEnabled: false
      }
    }, {
      multi: true
    });
    Players.update({
      playerId: player.playerId
    }, {
      $set: {
        isEnabled: true,
        singledAt: Date.now()
      }
    });
    Rooms.upsert({
      roomId: roomId
    }, {
      $set: {
        allEnabled: false,
        enabledPlayerId: player.playerId,
        message: player.name
      }
    });
  } else {
    Rooms.upsert({
      roomId: roomId
    }, {
      $set: {
        allEnabled: false,
        message: 'No players :('
      },
      $unset: {
        enabledPlayerId: ''
      }
    });
  }
  return Players.update({
    allEnabled: true,
    roomId: roomId
  }, {
    $set: {
      allEnabled: false
    }
  }, {
    multi: true
  });
};

enableAllPlayers = function(roomId) {
  Players.update({
    roomId: roomId
  }, {
    $set: {
      allEnabled: true,
      isEnabled: true
    }
  }, {
    multi: true
  });
  return Rooms.upsert({
    roomId: roomId
  }, {
    $set: {
      allEnabled: true,
      message: 'Everyone'
    },
    $unset: {
      enabledPlayerId: ''
    }
  });
};

disableAllPlayers = function(roomId) {
  Players.update({
    isEnabled: true,
    isMaster: false,
    roomId: roomId
  }, {
    $set: {
      isEnabled: false
    }
  }, {
    multi: true
  });
  Players.update({
    allEnabled: true,
    roomId: roomId
  }, {
    $set: {
      allEnabled: false
    }
  }, {
    multi: true
  });
  return Rooms.upsert({
    roomId: roomId
  }, {
    $set: {
      allEnabled: false
    },
    $unset: {
      enabledPlayerId: '',
      message: ''
    }
  });
};

})();
