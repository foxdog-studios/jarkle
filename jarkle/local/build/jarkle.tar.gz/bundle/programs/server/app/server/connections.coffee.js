(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.onConnection(function(connection) {
  return connection.onClose(function() {
    return RoomControls.leaveRooms(connection.id);
  });
});

})();
