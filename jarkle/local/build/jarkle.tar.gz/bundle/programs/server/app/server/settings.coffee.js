(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var settings, _ref;

this.ServerSettings = settings = (_ref = Meteor.settings) != null ? _ref : {};

_.defaults(settings, {
  players: {},
  viewer: {}
});

_.defaults(settings.players, {
  enableOnJoin: true
});

_.defaults(settings.viewer, {
  message: 'The Jarkle'
});

})();
