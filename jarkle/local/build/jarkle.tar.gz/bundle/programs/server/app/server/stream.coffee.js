(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.Stream = new Meteor.Stream('stream');

Stream.permissions.read(function() {
  return true;
});

Stream.permissions.write(function(eventName, event) {
  var cursor;
  if (event.isMaster) {
    return true;
  }
  cursor = Players.find({
    playerId: event.userId,
    isEnabled: true
  });
  return cursor.count() === 1;
}, false);

})();
